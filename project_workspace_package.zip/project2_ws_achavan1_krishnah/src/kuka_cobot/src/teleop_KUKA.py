#!/usr/bin/env python
import rospy

from std_msgs.msg import Float64

import sys, select, termios, tty

msg = """
This teleop helps control each and every joint individually.
From key 'w' to 'i' keys help move theta 1 to 7 respectively in counterclockwise direction by o.1 rad.
similarly, From key 'a' to 'j' keys help move theta 1 to 7 respectively in clockwise direction by o.1 rad.
Space Key ' ', brings the cobot in home postion i.e all thetas are zero.
Key 'n' and 'm' takes the cobot to pick and drop position respectively.


"""
e = """
Communications Failed
"""

def getKey():
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''

    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

turn1 = 0
turn2 = 0
turn3 = 0
turn4 = 0
turn5 = 0
turn6 = 0
turn7 = 0



if __name__=="__main__":
    settings = termios.tcgetattr(sys.stdin)
    
    rospy.init_node('turtlebot_teleop')

    pub_theta1 = rospy.Publisher('/kuka_cobot/Z_0_revolute_motor/command' ,Float64, queue_size=10) 
    pub_theta2 = rospy.Publisher('/kuka_cobot/Z_1_revolute_motor/command' ,Float64, queue_size=10) 
    pub_theta3 = rospy.Publisher('/kuka_cobot/Z_2_revolute_motor/command' ,Float64, queue_size=10) 
    pub_theta4 = rospy.Publisher('/kuka_cobot/Z_3_revolute_motor/command' ,Float64, queue_size=10) 
    pub_theta5 = rospy.Publisher('/kuka_cobot/Z_4_revolute_motor/command' ,Float64, queue_size=10) 
    pub_theta6 = rospy.Publisher('/kuka_cobot/Z_5_revolute_motor/command',Float64, queue_size=10) 
    pub_theta7 = rospy.Publisher('/kuka_cobot/Z_6_revolute_motor/command',Float64, queue_size=10) 
    
    try:
        print (msg)
        
        while(1):
            key = getKey()
            if key == 'w':
                turn1 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)

            if key == 'a':
                turn1 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)  

            elif key == 'e':
                turn2 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 

            elif key == 's':
                turn2 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)   

            elif key == 'r':
                turn3 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)   

            elif key == 'd':
                turn3 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)  

            elif key == 't':
                turn4 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)   

            elif key == 'f':
                turn4 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)    

            elif key == 'y':
                turn5 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)    
            
            elif key == 'g':
                turn5 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)    
            
            elif key == 'u':
                turn6 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)  

            elif key == 'h':
                turn6 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 

            elif key == 'i':
                turn7 += 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7)   
            
            elif key == 'j':
                turn7 -= 0.1
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 

            elif key == 'l':
                turn1 = 1.5708
                turn2 = 1.5708
                turn3 = 0
                turn4 = 1.5708
                turn5 = 0
                turn6 = 1.5708
                turn7 = 0
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 
            
            elif key == 'n':
                turn1 = 0
                turn2 = 0
                turn3 = 0
                turn4 = -1.5708
                turn5 = 0
                turn6 = 1.5708
                turn7 = 0
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 
                
            elif key == 'm':
                turn1 = 0
                turn2 = 0
                turn3 = -1.5708
                turn4 = -1.5708
                turn5 = 0
                turn6 = 1.5708
                turn7 = 0
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 
            

            elif key == ' ':
                turn1 = 0
                turn2 = 0
                turn3 = 0
                turn4 = 0
                turn5 = 0
                turn6 = 0
                turn7 = 0
                pub_theta1.publish(turn1)
                pub_theta2.publish(turn2)
                pub_theta3.publish(turn3)
                pub_theta4.publish(turn4)
                pub_theta5.publish(turn5)
                pub_theta6.publish(turn6)
                pub_theta7.publish(turn7) 

            elif (key == '\x03'):
	            break

            if key in ['w','a', 'e', 's', 'r', 'd', 't', 'f', 'y', 'g', 'u', 'h' 'i', 'j', 'l', 'n', 'm', ' ']:
                print("Theta1", turn1)
                print("Theta2", turn2)
                print("Theta3", turn3)
                print("Theta4", turn4)
                print("Theta5", turn5)
                print("Theta6", turn6)
                print("Theta7", turn7)
	    

    except:
        print (e)

        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
